let animationContainer = document.getElementById('animation-container');
for (var i = 0; i < 19; i++) {
	animationContainer.innerHTML += `
	<div class="game__fireflies game__fireflies--after"></div>`;

}